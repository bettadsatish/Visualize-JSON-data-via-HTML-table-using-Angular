import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface EmployeePercentage {
  employeeName: string;
  percentage: number;
}

@Injectable({ providedIn: 'root' })
export class TimeEntriesService {
  private apiUrl = 'http://127.0.0.1:5000/api';

  constructor(private http: HttpClient) {}

  getPercentages(): Observable<EmployeePercentage[]> {
    return this.http.get<EmployeePercentage[]>(`${this.apiUrl}/timeentries/percentages`);
  }
}
