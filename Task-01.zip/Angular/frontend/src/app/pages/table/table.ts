import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TimeEntriesService, EmployeeData } from './time-entries.service';

@Component({
  standalone: true,
  selector: 'app-employee-table',
  imports: [CommonModule],
  templateUrl: './table.html',
  styleUrls: ['./table.css']
})
export class EmployeeTableComponent implements OnInit {
  employees: EmployeeData[] = [];
  loading = true;

  constructor(private timeService: TimeEntriesService) {}

  ngOnInit(): void {
    this.timeService.getEmployeeHours().subscribe({
      next: (data) => {
        this.employees = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching data', err);
        this.loading = false;
      }
    });
  }
}
