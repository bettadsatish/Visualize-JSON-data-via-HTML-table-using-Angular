import { Component, OnInit } from '@angular/core';
import { NgIf } from '@angular/common';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartOptions, TooltipItem } from 'chart.js';
import { HttpClient } from '@angular/common/http';

@Component({
  standalone: true,
  selector: 'app-pie-chart',
  imports: [NgIf, BaseChartDirective],
  templateUrl: './pie-chart.html'
})
export class PieChartComponent implements OnInit {
  loading = true;

  // Tailwind-inspired palette (extend if you like)
  private PALETTE = [
    '#3b82f6', '#22c55e', '#eab308', '#ef4444', '#a855f7', '#06b6d4',
    '#f97316', '#10b981', '#f43f5e', '#8b5cf6', '#14b8a6', '#f59e0b'
  ];

  chartData: ChartData<'pie'> = { labels: [], datasets: [] };
  chartOptions: ChartOptions<'pie'> = {
    responsive: true,
    plugins: {
      legend: { position: 'bottom', labels: { boxWidth: 14, boxHeight: 14, usePointStyle: true, pointStyle: 'circle' } },
      title: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx: TooltipItem<'pie'>) => {
            const label = ctx.label ?? '';
            const value = ctx.parsed ?? 0;
            const total = (ctx.chart.data.datasets?.[0]?.data as number[]).reduce((a, b) => a + (b || 0), 0) || 1;
            const pct = ((value / total) * 100).toFixed(1);
            return `${label}: ${value}% (${pct}%)`.replace('% (%','% ('); // value is already percentage from your API
          }
        }
      }
    },
    layout: { padding: 8 },
    animation: { duration: 600, easing: 'easeOutQuart' }
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<{ employeeName: string; percentage: number }[]>(
      'http://127.0.0.1:5000/api/timeentries/percentages'
    ).subscribe({
      next: rows => {
        const labels = rows.map(r => r.employeeName);
        const data = rows.map(r => r.percentage);
        const colors = data.map((_, i) => this.PALETTE[i % this.PALETTE.length]);

        this.chartData = {
          labels,
          datasets: [{
            label: 'Work Share (%)',
            data,
            backgroundColor: colors,
            hoverBackgroundColor: colors,
            borderColor: '#ffffff',
            borderWidth: 2,
            hoverOffset: 8
          }]
        };
        this.loading = false;
      },
      error: err => { console.error(err); this.loading = false; }
    });
  }
}
