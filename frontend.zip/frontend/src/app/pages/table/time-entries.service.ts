import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface EmployeeData {
  employeeName: string;
  totalHours: number;
}

@Injectable({ providedIn: 'root' })
export class TimeEntriesService {
  private apiUrl = 'http://127.0.0.1:5000/api/timeentries';

  constructor(private http: HttpClient) {}

  getEmployeeHours(): Observable<EmployeeData[]> {
    return this.http.get<EmployeeData[]>(this.apiUrl);
  }
}
