import { Route } from '@angular/router';

export const routes: Route[] = [
  {
    path: '',
    loadComponent: () => import('./pages/home/home').then(m => m.HomeComponent)
  },
  {
    path: 'table',
    loadComponent: () => import('./pages/table/table').then(m => m.EmployeeTableComponent)
  },
  {
    path: 'pie-chart',
    loadComponent: () => import('./pages/pie-chart/pie-chart').then(m => m.PieChartComponent)
  },
  { path: '**', redirectTo: '' }
];
