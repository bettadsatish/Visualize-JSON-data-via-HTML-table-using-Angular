import express from 'express';
import axios from 'axios';
import cors from 'cors';

const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

const API_URL =
  'https://rc-vault-fap-live-1.azurewebsites.net/api/gettimeentries?code=vO17RnE8vuzXzPJo5eaLLjXjmRW07law99QTD90zat9FfOQJKKUcgQ==';

// --- shared logic to compute totals (in minutes) ---
async function computeTotalsMinutes(): Promise<{ totalsMap: Map<string, number>; totalMinutes: number }> {
  const response = await axios.get(API_URL, { timeout: 15000 });
  const rawData = Array.isArray(response.data) ? response.data : [];

  const totalsMap = new Map<string, number>();
  let totalMinutes = 0;

  for (const entry of rawData) {
    if (!entry || !entry.EmployeeName || !entry.StarTimeUtc || !entry.EndTimeUtc) continue;

    const name = String(entry.EmployeeName).trim();

    const start = new Date(entry.StarTimeUtc.endsWith('Z') ? entry.StarTimeUtc : entry.StarTimeUtc + 'Z');
    const end = new Date(entry.EndTimeUtc.endsWith('Z') ? entry.EndTimeUtc : entry.EndTimeUtc + 'Z');

    const s = end < start ? end : start;
    const e = end < start ? start : end;

    const durationMinutes = Math.max(0, Math.round((e.getTime() - s.getTime()) / 60000));

    totalsMap.set(name, (totalsMap.get(name) ?? 0) + durationMinutes);
    totalMinutes += durationMinutes;
  }

  return { totalsMap, totalMinutes };
}

// --- existing endpoint: totals in HOURS ---
app.get('/api/timeentries', async (_req, res) => {
  try {
    const { totalsMap } = await computeTotalsMinutes();

    const results = Array.from(totalsMap.entries())
      .map(([employeeName, totalMinutes]) => ({
        employeeName,
        totalHours: +(totalMinutes / 60).toFixed(2)
      }))
      .sort((a, b) => b.totalHours - a.totalHours);

    res.setHeader('Cache-Control', 'no-store');
    res.json(results);
  } catch (err: any) {
    console.error('Error fetching time entries:', err?.message || err);
    res.status(500).json({ error: 'Error fetching data' });
  }
});

// --- NEW endpoint: percentage share of total time ---
app.get('/api/timeentries/percentages', async (_req, res) => {
  try {
    const { totalsMap, totalMinutes } = await computeTotalsMinutes();

    if (totalMinutes === 0) {
      res.setHeader('Cache-Control', 'no-store');
      return res.json([]);
    }

    const results = Array.from(totalsMap.entries())
      .map(([employeeName, minutes]) => ({
        employeeName,
        percentage: +((minutes / totalMinutes) * 100).toFixed(2)
      }))
      .sort((a, b) => b.percentage - a.percentage);

    res.setHeader('Cache-Control', 'no-store');
    res.json(results);
  } catch (err: any) {
    console.error('Error computing percentages:', err?.message || err);
    res.status(500).json({ error: 'Error fetching data' });
  }
});

// start server
app.listen(port, '127.0.0.1', () => {
  console.log(`Backend running at http://127.0.0.1:${port}`);
});
